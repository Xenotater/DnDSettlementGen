DnD 5e Settlement Generator
Written by Kyler Froman, assisted by Michael Bledsoe's Algorithm

Feel free to use and share this program! You can edit some of the parameters within the settings.txt file. There's a key at the bottom of the file that tells what each setting does and how to edit them. 

If the program seems to be crashing, delete the settings file and run the program again. This should generate a fresh settings file.

If you need any assistance or would like to make a suggestion, DM me on discord: Xenotater#0303